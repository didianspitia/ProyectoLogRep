# Codigo de proyecto "Gestion de Tienda" para logica y representacion 1.

### Diagrama de clases
![Diagrama UML de clases](./images/diagramaDeClases.svg)
